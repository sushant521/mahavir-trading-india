import { Phone, MapPin, Mail } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground pt-16 pb-8 border-t-4 border-secondary">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          
          {/* About */}
          <div className="text-center md:text-left space-y-4">
            <h3 className="text-2xl font-display text-secondary">महावीर ट्रेडिंग</h3>
            <p className="opacity-80 leading-relaxed">
              सर्वोत्तम गुणवत्ता वाले सूखे मेवे और मसालों का विश्वसनीय स्रोत। हम पूरे भारत में डिलीवरी करते हैं।
              (Trusted source for premium dry fruits and spices. We deliver all over India.)
            </p>
          </div>

          {/* Contact Info */}
          <div className="text-center md:text-left space-y-4">
            <h3 className="text-xl font-bold font-display text-secondary mb-4">संपर्क करें (Contact Us)</h3>
            <ul className="space-y-3">
              <li className="flex items-center justify-center md:justify-start gap-3 opacity-90">
                <MapPin className="w-5 h-5 text-secondary shrink-0" />
                <span>विशेश्वरगंज, वाराणसी, उत्तर प्रदेश<br/>(Vishesharganj, Varanasi, UP)</span>
              </li>
              <li className="flex items-center justify-center md:justify-start gap-3 opacity-90">
                <Phone className="w-5 h-5 text-secondary shrink-0" />
                <div className="flex flex-col">
                  <span>+91 9307155027</span>
                  <span>+91 7525000887</span>
                </div>
              </li>
            </ul>
          </div>

          {/* Quick Links */}
          <div className="text-center md:text-left space-y-4">
            <h3 className="text-xl font-bold font-display text-secondary mb-4">समय (Hours)</h3>
            <ul className="space-y-2 opacity-90">
              <li className="flex justify-between md:justify-start md:gap-8 border-b border-white/10 pb-2">
                <span>सोमवार - शनिवार</span>
                <span>10:00 AM - 08:00 PM</span>
              </li>
              <li className="flex justify-between md:justify-start md:gap-8 pt-2 text-secondary">
                <span>रविवार (Sunday)</span>
                <span>बंद (Closed)</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="text-center pt-8 border-t border-white/10 text-sm opacity-60">
          <p>&copy; {new Date().getFullYear()} Mahavir Trading Pvt. Ltd. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
