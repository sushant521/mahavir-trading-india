import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { type Product } from "@shared/schema";

interface ProductCardProps {
  product: Product;
  index: number;
}

export function ProductCard({ product, index }: ProductCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      viewport={{ once: true }}
      className="group bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 border border-border/50 flex flex-col h-full"
    >
      <div className="relative aspect-square overflow-hidden bg-muted">
        {product.isFeatured && (
          <Badge className="absolute top-3 left-3 z-10 bg-secondary text-secondary-foreground hover:bg-secondary/90 font-bold shadow-md">
            Featured
          </Badge>
        )}
        <img
          src={product.imageUrl}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
          <a 
            href="https://wa.me/919307155027" 
            target="_blank"
            rel="noreferrer" 
            className="w-full bg-green-600 text-white py-2 rounded-lg font-bold text-center shadow-lg hover:bg-green-700 transition-colors"
          >
            WhatsApp Order
          </a>
        </div>
      </div>

      <div className="p-5 flex-1 flex flex-col">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-display text-xl font-bold text-primary group-hover:text-accent transition-colors">
            {product.name}
          </h3>
          <span className="text-xs font-bold px-2 py-1 bg-muted rounded text-muted-foreground uppercase tracking-wider">
            {product.category === 'dry_fruits' ? 'Dry Fruit' : 'Spice'}
          </span>
        </div>
        <p className="text-muted-foreground text-sm line-clamp-3 leading-relaxed flex-1">
          {product.description}
        </p>
      </div>
    </motion.div>
  );
}
