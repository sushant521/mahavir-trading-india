import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { insertContactRequestSchema, type InsertContactRequest } from "@shared/schema";
import { useCreateContact } from "@/hooks/use-contact";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Send, Loader2 } from "lucide-react";

export function ContactForm() {
  const { mutate, isPending } = useCreateContact();
  
  const form = useForm<InsertContactRequest>({
    resolver: zodResolver(insertContactRequestSchema),
    defaultValues: {
      name: "",
      mobile: "",
      message: "",
    },
  });

  function onSubmit(data: InsertContactRequest) {
    mutate(data, {
      onSuccess: () => form.reset(),
    });
  }

  return (
    <div className="bg-white p-6 md:p-8 rounded-2xl shadow-xl border border-secondary/20 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary via-secondary to-primary"></div>
      
      <div className="mb-6">
        <h3 className="text-2xl font-display font-bold text-primary mb-2">पूछताछ करें (Inquiry)</h3>
        <p className="text-muted-foreground text-sm">
          थोक मूल्य और ऑर्डर्स के लिए फॉर्म भरें या सीधे कॉल करें।
          <br/>(Fill form for wholesale prices and orders.)
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-primary font-bold">नाम (Name)</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="आपका नाम (Your Name)" 
                    className="h-12 border-muted-foreground/20 focus:border-secondary focus:ring-secondary/20" 
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="mobile"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-primary font-bold">मोबाइल (Mobile)</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="आपका नंबर (Your Number)" 
                    className="h-12 border-muted-foreground/20 focus:border-secondary focus:ring-secondary/20" 
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="message"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-primary font-bold">संदेश (Message)</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="आप क्या खरीदना चाहते हैं? (What do you want to buy?)" 
                    className="min-h-[120px] resize-none border-muted-foreground/20 focus:border-secondary focus:ring-secondary/20" 
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <Button 
            type="submit" 
            disabled={isPending}
            className="w-full h-12 text-lg font-bold bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/25"
          >
            {isPending ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                भेज रहा है...
              </>
            ) : (
              <>
                <Send className="w-5 h-5 mr-2" />
                संदेश भेजें (Send Message)
              </>
            )}
          </Button>
        </form>
      </Form>
    </div>
  );
}
