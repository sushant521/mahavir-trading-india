import { Link } from "wouter";
import { Phone, MapPin, Clock } from "lucide-react";

export function Header() {
  return (
    <header className="w-full bg-white shadow-md relative z-50">
      {/* Top Bar - Religious & Hours */}
      <div className="bg-primary text-primary-foreground py-2 px-4 text-center text-sm md:text-base font-medium tracking-wide">
        <div className="container mx-auto flex flex-col md:flex-row justify-between items-center gap-2">
          <span className="font-display text-lg text-yellow-300">ॐ गणेशाय नमः</span>
          <div className="flex items-center gap-4 text-xs md:text-sm opacity-90">
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3" /> सोमवार - शनिवार (Mon-Sat)
            </span>
            <span className="hidden md:inline">|</span>
            <span className="flex items-center gap-1">
              <MapPin className="w-3 h-3" /> विशेश्वरगंज (Vishesharganj)
            </span>
          </div>
        </div>
      </div>

      {/* Main Header Content */}
      <div className="container mx-auto px-4 py-6 md:py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          
          {/* Logo / Name */}
          <div className="text-center md:text-left">
            <Link href="/">
              <div className="cursor-pointer group">
                <h1 className="text-3xl md:text-4xl lg:text-5xl font-display font-bold text-primary mb-1 group-hover:text-primary/90 transition-colors">
                  महावीर ट्रेडिंग
                </h1>
                <h2 className="text-lg md:text-xl text-secondary font-semibold tracking-wider">
                  प्राइवेट लिमिटेड
                </h2>
              </div>
            </Link>
            <p className="text-sm text-muted-foreground mt-2 font-medium">
              प्रो. संतोष कुमार अग्रवाल (Prop. Santosh Kumar Agrawal)
            </p>
          </div>

          {/* Contact Actions */}
          <div className="flex flex-col gap-3 items-center md:items-end">
            <p className="text-sm font-bold text-muted-foreground uppercase tracking-widest mb-1">
              अभी ऑर्डर करें (Order Now)
            </p>
            <div className="flex gap-3">
              <a 
                href="https://wa.me/919307155027" 
                target="_blank" 
                rel="noreferrer"
                className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-full font-bold transition-all hover:-translate-y-1 shadow-lg shadow-green-600/20"
              >
                <Phone className="w-4 h-4 fill-current" />
                9307155027
              </a>
              <a 
                href="https://wa.me/917525000887" 
                target="_blank" 
                rel="noreferrer"
                className="flex items-center gap-2 bg-primary hover:bg-primary/90 text-white px-4 py-2 rounded-full font-bold transition-all hover:-translate-y-1 shadow-lg shadow-primary/20"
              >
                <Phone className="w-4 h-4 fill-current" />
                7525000887
              </a>
            </div>
          </div>
        </div>
      </div>
      
      {/* Decorative Border Bottom */}
      <div className="h-1 w-full bg-gradient-to-r from-primary via-secondary to-primary"></div>
    </header>
  );
}
