import { motion } from "framer-motion";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ProductCard } from "@/components/ProductCard";
import { ContactForm } from "@/components/ContactForm";
import { useProducts } from "@/hooks/use-products";
import { Phone, Star, ShieldCheck, Truck } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const { data: products, isLoading } = useProducts();

  // Filter products by category
  const dryFruits = products?.filter(p => p.category === 'dry_fruits') || [];
  const spices = products?.filter(p => p.category === 'spices') || [];

  return (
    <div className="min-h-screen flex flex-col bg-pattern-mandala">
      <Header />

      <main className="flex-1">
        
        {/* Hero Section */}
        <section className="relative bg-primary py-16 md:py-24 overflow-hidden">
          {/* Decorative background image overlay */}
          <div className="absolute inset-0 opacity-20 bg-[url('https://images.unsplash.com/photo-1596040033229-a9821ebd058d?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center mix-blend-overlay"></div>
          
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-3xl mx-auto text-center space-y-6">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
              >
                <h1 className="text-4xl md:text-6xl lg:text-7xl font-display font-bold text-white mb-4 leading-tight">
                  शुद्धता और स्वाद<br/>
                  <span className="text-secondary">का वादा</span>
                </h1>
                <p className="text-xl md:text-2xl text-primary-foreground/90 font-light max-w-2xl mx-auto">
                  प्रीमियम क्वालिटी के सूखे मेवे और असली मसाले सीधे थोक दरों पर।
                  <br/>(Premium quality dry fruits & authentic spices at wholesale rates.)
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.4 }}
                className="pt-8"
              >
                <a 
                  href="#products"
                  className="inline-block px-8 py-4 bg-secondary text-primary-foreground font-bold text-lg rounded-full shadow-xl shadow-secondary/30 hover:bg-white hover:text-primary transition-all hover:-translate-y-1"
                >
                  उत्पाद देखें (View Products)
                </a>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Features / Trust Indicators */}
        <section className="py-12 bg-white shadow-sm relative z-20 -mt-8 mx-4 md:mx-auto max-w-6xl rounded-2xl border border-gray-100">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 px-6 text-center">
            <div className="flex flex-col items-center gap-3">
              <div className="w-16 h-16 rounded-full bg-orange-100 flex items-center justify-center text-orange-600 mb-2">
                <ShieldCheck className="w-8 h-8" />
              </div>
              <h3 className="font-display text-xl font-bold text-primary">100% शुद्ध (Pure)</h3>
              <p className="text-muted-foreground text-sm">सर्वोत्तम गुणवत्ता की गारंटी</p>
            </div>
            <div className="flex flex-col items-center gap-3 border-y md:border-y-0 md:border-x border-gray-100 py-6 md:py-0">
              <div className="w-16 h-16 rounded-full bg-yellow-100 flex items-center justify-center text-yellow-600 mb-2">
                <Star className="w-8 h-8" />
              </div>
              <h3 className="font-display text-xl font-bold text-primary">प्रीमियम (Premium)</h3>
              <p className="text-muted-foreground text-sm">चयनित बेहतरीन सामग्री</p>
            </div>
            <div className="flex flex-col items-center gap-3">
              <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center text-green-600 mb-2">
                <Truck className="w-8 h-8" />
              </div>
              <h3 className="font-display text-xl font-bold text-primary">पूरे भारत में डिलीवरी</h3>
              <p className="text-muted-foreground text-sm">अखिल भारतीय शिपिंग (Pan India)</p>
            </div>
          </div>
        </section>

        {/* Products Section - Dry Fruits */}
        <section id="products" className="py-20 container mx-auto px-4">
          <div className="flex items-center gap-4 mb-12">
            <div className="h-px bg-secondary/50 flex-1"></div>
            <h2 className="text-3xl md:text-5xl font-display font-bold text-primary text-center">सूखे मेवे (Dry Fruits)</h2>
            <div className="h-px bg-secondary/50 flex-1"></div>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="space-y-4">
                  <Skeleton className="h-64 w-full rounded-xl" />
                  <Skeleton className="h-8 w-3/4" />
                  <Skeleton className="h-4 w-full" />
                </div>
              ))}
            </div>
          ) : dryFruits.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {dryFruits.map((product, index) => (
                <ProductCard key={product.id} product={product} index={index} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-muted-foreground bg-white/50 rounded-xl border border-dashed border-secondary/30">
              No products available yet.
            </div>
          )}
        </section>

        {/* Parallax / Divider Section */}
        <section className="py-24 bg-primary relative overflow-hidden flex items-center justify-center text-center px-4">
          {/* Spices background */}
          <div className="absolute inset-0 opacity-20 bg-[url('https://images.unsplash.com/photo-1596040033229-a9821ebd058d?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-fixed bg-center"></div>
          
          <div className="relative z-10 max-w-4xl mx-auto space-y-6">
            <h2 className="text-4xl md:text-6xl font-display font-bold text-secondary">स्वाद की परंपरा</h2>
            <p className="text-xl md:text-2xl text-white font-light">
              "हमारे मसाले आपके भोजन में वह स्वाद लाते हैं जो आपको घर की याद दिलाता है।"
              <br/>
              (Our spices bring the taste that reminds you of home.)
            </p>
          </div>
        </section>

        {/* Products Section - Spices */}
        <section className="py-20 container mx-auto px-4 bg-white/50">
          <div className="flex items-center gap-4 mb-12">
            <div className="h-px bg-secondary/50 flex-1"></div>
            <h2 className="text-3xl md:text-5xl font-display font-bold text-primary text-center">मसाले (Spices)</h2>
            <div className="h-px bg-secondary/50 flex-1"></div>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="space-y-4">
                  <Skeleton className="h-64 w-full rounded-xl" />
                  <Skeleton className="h-8 w-3/4" />
                  <Skeleton className="h-4 w-full" />
                </div>
              ))}
            </div>
          ) : spices.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {spices.map((product, index) => (
                <ProductCard key={product.id} product={product} index={index} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-muted-foreground bg-white/50 rounded-xl border border-dashed border-secondary/30">
              No spices available yet.
            </div>
          )}
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-20 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="flex flex-col lg:flex-row gap-12 items-center">
              
              <div className="w-full lg:w-1/2 space-y-8">
                <div className="space-y-4">
                  <h2 className="text-4xl md:text-5xl font-display font-bold text-primary">संपर्क करें (Contact Us)</h2>
                  <p className="text-lg text-muted-foreground leading-relaxed">
                    किसी भी थोक ऑर्डर या पूछताछ के लिए बेझिझक संपर्क करें। हम आपकी सेवा में सदैव तत्पर हैं।
                  </p>
                </div>

                <div className="grid gap-6">
                  <div className="flex items-center gap-4 p-6 bg-white rounded-xl shadow-md border border-border">
                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center text-green-600 shrink-0">
                      <Phone className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-bold text-foreground">WhatsApp / Call</h4>
                      <p className="text-primary font-display text-xl">9307155027</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4 p-6 bg-white rounded-xl shadow-md border border-border">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 shrink-0">
                      <Phone className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-bold text-foreground">Alternate Number</h4>
                      <p className="text-primary font-display text-xl">7525000887</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="w-full lg:w-1/2 flex justify-center">
                <a 
                  href="https://wa.me/919307155027" 
                  target="_blank" 
                  rel="noreferrer"
                  className="flex flex-col items-center gap-6 p-12 bg-green-50 rounded-3xl border-4 border-green-200 hover:bg-green-100 transition-all hover:scale-105 shadow-2xl group"
                >
                  <div className="w-24 h-24 bg-green-600 rounded-full flex items-center justify-center text-white shadow-lg group-hover:rotate-12 transition-transform">
                    <Phone className="w-12 h-12" />
                  </div>
                  <div className="text-center space-y-2">
                    <h3 className="text-3xl font-display font-bold text-green-800">व्हाट्सएप पर संपर्क करें</h3>
                    <p className="text-xl text-green-700 font-medium">(Contact on WhatsApp)</p>
                    <p className="text-4xl font-display font-bold text-green-600 mt-4">9307155027</p>
                  </div>
                </a>
              </div>
            </div>
          </div>
        </section>

      </main>
      
      <Footer />
    </div>
  );
}
