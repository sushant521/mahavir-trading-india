## Packages
framer-motion | Smooth animations and page transitions
lucide-react | Beautiful icons for the UI

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["var(--font-sans)"],
  display: ["var(--font-display)"],
  hindi: ["var(--font-hindi)"],
}
