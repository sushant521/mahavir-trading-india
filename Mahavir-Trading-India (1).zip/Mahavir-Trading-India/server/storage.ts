import { products, contactRequests, type Product, type InsertProduct, type ContactRequest, type InsertContactRequest } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createContactRequest(request: InsertContactRequest): Promise<ContactRequest>;
  seedProducts(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getProducts(): Promise<Product[]> {
    return await db.select().from(products);
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async createContactRequest(request: InsertContactRequest): Promise<ContactRequest> {
    const [newRequest] = await db.insert(contactRequests).values(request).returning();
    return newRequest;
  }

  async seedProducts(): Promise<void> {
    const existing = await this.getProducts();
    
    // Always add the "Other" product if it doesn't exist
    const otherProduct = existing.find(p => p.name === "अन्य सूखे मेवे और मसाले (Other Dry Fruits & Spices)");
    if (!otherProduct) {
      await db.insert(products).values({
        name: "अन्य सूखे मेवे और मसाले (Other Dry Fruits & Spices)",
        category: "dry_fruits",
        description: "हमारे पास पूरे भारत से सभी प्रकार के सूखे मेवे और मसाले उपलब्ध हैं। किसी भी अन्य सामग्री के लिए हमें व्हाट्सएप करें।",
        imageUrl: "https://placehold.co/600x400?text=All+Dry+Fruits+%26+Spices",
        isFeatured: true
      });
    }

    if (existing.length > 0) return;

    const seedData: InsertProduct[] = [
      // Dry Fruits
      {
        name: "बादाम (Almonds)",
        category: "dry_fruits",
        description: "Premium quality California almonds. Best for health and taste.",
        imageUrl: "https://placehold.co/600x400?text=Almonds+(Badam)",
        isFeatured: true
      },
      {
        name: "काजू (Cashews)",
        category: "dry_fruits",
        description: "Whole white cashews, rich and creamy.",
        imageUrl: "https://placehold.co/600x400?text=Cashews+(Kaju)",
        isFeatured: true
      },
      {
        name: "किशमिश (Raisins)",
        category: "dry_fruits",
        description: "Sweet and juicy golden raisins.",
        imageUrl: "https://placehold.co/600x400?text=Raisins+(Kishmish)",
        isFeatured: false
      },
      {
        name: "पिस्ता (Pistachios)",
        category: "dry_fruits",
        description: "Salted and roasted pistachios.",
        imageUrl: "https://placehold.co/600x400?text=Pistachios+(Pista)",
        isFeatured: true
      },
      {
        name: "अखरोट (Walnuts)",
        category: "dry_fruits",
        description: "High quality walnuts with shell/without shell.",
        imageUrl: "https://placehold.co/600x400?text=Walnuts+(Akhrot)",
        isFeatured: false
      },
      // Spices
      {
        name: "इलायची (Cardamom)",
        category: "spices",
        description: "Aromatic green cardamom pods.",
        imageUrl: "https://placehold.co/600x400?text=Cardamom+(Elaichi)",
        isFeatured: true
      },
      {
        name: "लौंग (Cloves)",
        category: "spices",
        description: "Premium quality cloves for rich flavor.",
        imageUrl: "https://placehold.co/600x400?text=Cloves+(Laung)",
        isFeatured: false
      },
      {
        name: "काली मिर्च (Black Pepper)",
        category: "spices",
        description: "Bold and spicy black pepper corns.",
        imageUrl: "https://placehold.co/600x400?text=Black+Pepper+(Kali+Mirch)",
        isFeatured: true
      },
      {
        name: "जीरा (Cumin)",
        category: "spices",
        description: "Whole cumin seeds for authentic taste.",
        imageUrl: "https://placehold.co/600x400?text=Cumin+(Jeera)",
        isFeatured: false
      },
      {
        name: "हल्दी (Turmeric)",
        category: "spices",
        description: "Pure turmeric powder/roots.",
        imageUrl: "https://placehold.co/600x400?text=Turmeric+(Haldi)",
        isFeatured: false
      }
    ];

    await db.insert(products).values(seedData);
  }
}

export const storage = new DatabaseStorage();
